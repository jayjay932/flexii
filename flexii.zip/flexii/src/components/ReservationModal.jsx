import { useState } from 'react';
import './reservation.css';

function ReservationModal({ visible, onClose, onResults }) {
  const [location, setLocation] = useState('');
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState('');

  if (!visible) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    if (!location || !checkIn || !checkOut || !guests) {
      alert("Merci de remplir tous les champs.");
      return;
    }
  
    console.log("Requête envoyée avec :", { location, checkIn, checkOut, guests });

    if (new Date(checkIn) > new Date(checkOut)) {
        alert("La date de check-in doit être avant la date de check-out.");
        return;
      }
      
  
    try {
      const res = await fetch(
        `http://localhost/flexii/api/search_listings.php?location=${encodeURIComponent(location)}&guests=${guests}&start=${checkIn}&end=${checkOut}`
      );
      const data = await res.json();
  
      console.log("Réponse API :", data);
  
      if (onResults) onResults(data); // si défini
      if (onClose) onClose();         // si défini
    } catch (err) {
      console.error("Erreur API :", err);
      alert("Une erreur est survenue.");
    }
  };
  
  return (
    <div className="reservation-overlay">
      <div className="reservation-container">
        <div className="form-header">
          <h1>Make your reservation</h1>
          <button onClick={onClose} className="close-btn">&times;</button>
        </div>
        <form className="booking-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <input
              className="form-control"
              type="text"
              placeholder="Country, ZIP, city..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
            <span className="form-label">Destination</span>
          </div>
          <div className="row">
            <div className="form-group half">
              <input
                className="form-control"
                type="date"
                required
                value={checkIn}
                onChange={(e) => setCheckIn(e.target.value)}
              />
              <span className="form-label">Check In</span>
            </div>
            <div className="form-group half">
              <input
                className="form-control"
                type="date"
                required
                value={checkOut}
                onChange={(e) => setCheckOut(e.target.value)}
              />
              <span className="form-label">Check Out</span>
            </div>
          </div>
          <div className="form-group">
            <select
              className="form-control"
              value={guests}
              onChange={(e) => setGuests(e.target.value)}
              required
            >
              <option hidden value="">No. of guests</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3+</option>
            </select>
            <span className="form-label">Guests</span>
          </div>
          <button type="submit" className="submit-btn">Book Now</button>
        </form>
      </div>
    </div>
  );
}

export default ReservationModal;
