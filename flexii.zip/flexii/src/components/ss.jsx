import styles from '../styles/Detail.module.css';
import hostStyles from '../styles/DetailHost.module.css';
import rulesStyles from '../styles/DetailRules.module.css';
import descripStyles from '../styles/DetailDescrip.module.css';
import gridStyles from '../styles/ImageGrid.module.css'