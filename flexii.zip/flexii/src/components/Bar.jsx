import './bar.css';

function Bar() {
  return (
    <div className="bar">
      <div className="f">
        <h1><u>Learn about Guests' favorites, the most loved homes on Airbnb</u></h1>
      </div>
    </div>
  );
}

export default Bar;
