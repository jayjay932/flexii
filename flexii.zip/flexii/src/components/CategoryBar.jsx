import './categorybar.css';

const categories = [
  { name: 'Iconic cities', img: 'https://a0.muscache.com/pictures/3fb523a0-b622-4368-8142-b5e03df7549b.jpg' },
  { name: 'Countryside', img: 'https://a0.muscache.com/pictures/4221e293-4770-4ea8-a4fa-9972158d4004.jpg' },
  { name: 'Earth homes', img: 'https://a0.muscache.com/pictures/3fb523a0-b622-4368-8142-b5e03df7549b.jpg' },
  { name: 'Amazing views', img: 'https://a0.muscache.com/pictures/3fb523a0-b622-4368-8142-b5e03df7549b.jpg' },
  { name: 'OMG!', img: 'https://a0.muscache.com/pictures/3fb523a0-b622-4368-8142-b5e03df7549b.jpg' },
  { name: 'Domes', img: 'https://a0.muscache.com/pictures/3fb523a0-b622-4368-8142-b5e03df7549b.jpg' },
  { name: 'Creative spaces', img: 'https://a0.muscache.com/pictures/3fb523a0-b622-4368-8142-b5e03df7549b.jpg' },
  { name: 'Trending', img: 'https://a0.muscache.com/pictures/3fb523a0-b622-4368-8142-b5e03df7549b.jpg' },
  { name: 'Castles', img: 'https://a0.muscache.com/pictures/3fb523a0-b622-4368-8142-b5e03df7549b.jpg' }
];

function CategoryBar({ onSortChange }) {
  return (
    <div className="flexbox3">
      <div className="icon4"><i className="bi bi-caret-left-fill"></i></div>
      <div className="Allicons">
        {categories.map((cat, index) => (
          <div className="icon3" key={index}>
            <img src={cat.img} alt={cat.name} />
            <br />
            <p>{cat.name}</p>
          </div>
        ))}
      </div>
      <div className="f2">
        <div className="icon4"><i className="bi bi-caret-right-fill"></i></div>
        <button className="fl2">
          <i className="bi bi-sliders2"></i><h4>Filters</h4>
        </button>
        <div className="sort-container">
          <i className="bi bi-arrow-down-up"></i>
          <select className="sort-select" onChange={(e) => onSortChange(e.target.value)}>
            <option value="">Sort by</option>
            <option value="price_low">Low to High</option>
            <option value="price_high">High to Low</option>
            <option value="newest">Newest</option>
          </select>
        </div>
      </div>
    </div>
  );
}

export default CategoryBar;
