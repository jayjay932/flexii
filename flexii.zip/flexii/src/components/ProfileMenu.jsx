import './card.css';
import './filter.css';
import './searchbar.css';
import './imagegrid.css';
import './mobilemenu.css';

function ProfileMenu({ isLoggedIn, onLoginClick, onSignupClick, visible }) {
    console.log("ProfileMenu visible:", visible); // ← Ajout temporaire

    if (!visible) return null;

  return (
    <div id="profileMenu" className="profile-menu" style={{ display: 'block', background: 'white', position: 'absolute', top: '60px', right: '20px', zIndex: 1000 }}>

      <ul>
        {isLoggedIn ? (
          <>
            <li><a href="#">Messages</a></li>
            <li><a href="#">Notifications <span className="notif-dot"></span></a></li>
            <li><a href="#">Voyages</a></li>
            <li><a href="#">Favoris</a></li>
            <hr />
            <li><a href="#">Gérer mes annonces</a></li>
            <li><a href="#">Créer une expérience</a></li>
            <li><a href="#">Parrainer un hôte</a></li>
            <li><a href="#">Compte</a></li>
            <hr />
            <li><a href="#">Cartes cadeaux</a></li>
            <li><a href="#">Centre d'aide</a></li>
            <li><a href="http://localhost/flexii/api/logout.php">Déconnexion</a></li>
          </>
        ) : (
          <>
            <li><a href="#" onClick={onLoginClick}>Connexion</a></li>
            <li><a href="#" onClick={onSignupClick}>Inscription</a></li>
            <li><a href="#">Mettre mon logement</a></li>
            <li><a href="#">Créer une expérience</a></li>
            <li><a href="#">Centre d'aide</a></li>
          </>
        )}
      </ul>
    </div>
  );
}

export default ProfileMenu;