// src/App.jsx
import React, { useState, useEffect, createContext } from 'react';
import { Routes, Route } from 'react-router-dom';

import HomePage             from './pages/HomePage.jsx';
import ListingDetails       from './pages/ListingDetails.jsx';
import AfficherCommentaires from './components/AfficherCommentaires.jsx';
import CheckoutPage         from './pages/CheckoutPage.jsx';

import './styles/card.css';
import './styles/filter.css';
import './styles/searchbar.css';
import './styles/mobilemenu.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

// Contexte d’auth: on expose un objet { auth, setAuth }
export const AuthContext = createContext({
  auth:    { loggedIn: false, user: null, loading: false },
  setAuth: () => {}
});

function App() {
  const [auth, setAuth] = useState({
    loggedIn: false,
    user:     null,
    loading:  true
  });

  useEffect(() => {
    fetch('http://localhost/flexii/api/check_session.php', {
      credentials: 'include'
    })
      .then(res => res.json())
      .then(data => {
        if (data.loggedIn) {
          setAuth({ loggedIn: true,  user: data.user, loading: false });
        } else {
          setAuth({ loggedIn: false, user: null,     loading: false });
        }
      })
      .catch(() => {
        setAuth({ loggedIn: false, user: null, loading: false });
      });
  }, []);

  // Pendant qu’on attend la réponse du backend
  if (auth.loading) {
    return <div>Vérification de la session…</div>;
  }

  return (
    <AuthContext.Provider value={{ auth, setAuth }}>
      <Routes>
        <Route path="/"                        element={<HomePage />} />
        <Route path="/listing/:id"             element={<ListingDetails />} />
        <Route path="/afficher_commentaires/:id" element={<AfficherCommentaires />} />
        <Route path="/checkout"                element={<CheckoutPage />} />
      </Routes>
    </AuthContext.Provider>
  );
}

export default App;
