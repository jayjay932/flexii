import React, { useState, useEffect, useContext } from 'react';
import Header from '../components/Header';
import MobileMenu from '../components/MobileMenu';
import ProfileMenu from '../components/ProfileMenu';
import LoginModal from '../components/LoginModal';
import SignupModal from '../components/SignupModal';
import Listings from '../components/Listings';
import CategoryBar from '../components/categorybar';
import MobileSearchBar from '../components/MobileSearchBar';
import Bar from '../components/Bar';
import ReservationModal from '../components/ReservationModal';
import BottomNav from '../components/BottomNav';
import { AuthContext } from '../App';

function HomePage() {
  // Global auth context
  const { auth, setAuth } = useContext(AuthContext);
  const { loggedIn, user } = auth;

  // UI state
  const [loginVisible, setLoginVisible] = useState(false);
  const [signupVisible, setSignupVisible] = useState(false);
  const [showReservation, setShowReservation] = useState(false);
  const [reloadListings, setReloadListings] = useState(false);
  const [sortOption, setSortOption] = useState('');
  const [filteredListings, setFilteredListings] = useState(null);
  const [defaultListings, setDefaultListings] = useState([]);
  const [menuVisible, setMenuVisible] = useState(false);

  const openLogin = () => setLoginVisible(true);
  const closeLogin = () => setLoginVisible(false);
  const openSignup = () => setSignupVisible(true);
  const closeSignup = () => setSignupVisible(false);
  const toggleMenu = () => setMenuVisible(v => !v);
  const resetFilters = () => setFilteredListings(null);

  // Handlers for auth modals
  const handleLoginSuccess = (userData) => {
    setAuth({ loggedIn: true, user: userData, loading: false });
    closeLogin();
    setReloadListings(r => !r);
  };

  const handleSignupSuccess = (userData) => {
    setAuth({ loggedIn: true, user: userData, loading: false });
    closeSignup();
    setReloadListings(r => !r);
  };

  // Fetch listings whenever reloadListings changes
  useEffect(() => {
    fetch("http://localhost/flexii/api/listings.php", {
      credentials: 'include'
    })
      .then(res => res.json())
      .then(data => setDefaultListings(data));
  }, [reloadListings]);

  // Sort & filter
  const applySort = (list) => {
    if (!list) return [];
    switch (sortOption) {
      case 'price_low': return [...list].sort((a, b) => a.price_per_night - b.price_per_night);
      case 'price_high': return [...list].sort((a, b) => b.price_per_night - a.price_per_night);
      case 'newest': return [...list].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
      default: return list;
    }
  };

  return (
    <>
      <Bar />
      <MobileMenu />
      <Header
        isLoggedIn={loggedIn}
        avatarUrl={user?.avatar || '/flexii.png'}
        onAvatarClick={toggleMenu}
      />
      <ProfileMenu
        isLoggedIn={loggedIn}
        onLoginClick={openLogin}
        onSignupClick={openSignup}
        visible={menuVisible}
      />

      <LoginModal
        visible={loginVisible}
        onClose={closeLogin}
        onSwitch={() => { closeLogin(); openSignup(); }}
        onLoginSuccess={handleLoginSuccess}
      />

      <SignupModal
        visible={signupVisible}
        onClose={closeSignup}
        onSwitch={() => { closeSignup(); openLogin(); }}
        onSignupSuccess={handleSignupSuccess}
      />

      <CategoryBar onSortChange={setSortOption} />
      <MobileSearchBar onClick={() => setShowReservation(true)} />
      <ReservationModal
        visible={showReservation}
        onClose={() => setShowReservation(false)}
        onResults={results => setFilteredListings(results)}
      />

      <Listings
        listings={applySort(filteredListings || defaultListings)}
        isLoggedIn={loggedIn}
        onLoginClick={openLogin}
        reload={reloadListings}
        sortOption={sortOption}
        onResetFilters={resetFilters}
      />

      <BottomNav
        isLoggedIn={loggedIn}
        onLoginClick={openLogin}
        onSignupClick={openSignup}
      />
    </>
  );
}

export default HomePage;
