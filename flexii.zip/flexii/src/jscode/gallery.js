

function openGallery() {
  document.getElementById('fullGallery').style.display = 'block';
}

function closeGallery() {
  document.getElementById('fullGallery').style.display = 'none';
}

